package com.example.employee;

import java.util.Comparator;

public class EmployeeComparator {

    // Comparator for sorting by Name
    public static class NameComparator implements Comparator<Employee> {
        @Override
        public int compare(Employee e1, Employee e2) {
            return e1.getName().compareTo(e2.getName());
        }
    }

    // Comparator for sorting by Salary
    public static class SalaryComparator implements Comparator<Employee> {
        @Override
        public int compare(Employee e1, Employee e2) {
            return Double.compare(e1.getSalary(), e2.getSalary());
        }
    }
}
