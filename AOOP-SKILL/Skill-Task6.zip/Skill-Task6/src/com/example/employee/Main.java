package com.example.employee;

public class Main {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();

        // Adding Employees
        manager.addEmployee(new Employee(103, "Alice", 55000));
        manager.addEmployee(new Employee(101, "Bob", 70000));
        manager.addEmployee(new Employee(102, "Charlie", 60000));

        // Sorting by ID
        System.out.println("\nSorted by ID:");
        manager.sortById();
        for (Employee e : manager) {
            System.out.println(e);
        }

        // Sorting by Name
        System.out.println("\nSorted by Name:");
        manager.sortByName();
        for (Employee e : manager) {
            System.out.println(e);
        }

        // Sorting by Salary
        System.out.println("\nSorted by Salary:");
        manager.sortBySalary();
        for (Employee e : manager) {
            System.out.println(e);
        }

        // Cloning an Employee
        Employee clonedEmployee = manager.getEmployees().get(0).clone();
        System.out.println("\nCloned Employee: " + clonedEmployee);
    }
}
