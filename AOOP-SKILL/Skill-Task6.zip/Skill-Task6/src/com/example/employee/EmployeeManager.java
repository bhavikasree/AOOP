package com.example.employee;

import java.util.*;

public class EmployeeManager implements Iterable<Employee> {
    private List<Employee> employees;

    // Constructor
    public EmployeeManager() {
        this.employees = new ArrayList<>();
    }

    // Add Employee
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    // Sort by ID (using Comparable)
    public void sortById() {
        Collections.sort(employees);
    }

    // Sort by Name (using Comparator)
    public void sortByName() {
        employees.sort(new EmployeeComparator.NameComparator());
    }

    // Sort by Salary (using Comparator)
    public void sortBySalary() {
        employees.sort(new EmployeeComparator.SalaryComparator());
    }

    // Get Employees
    public List<Employee> getEmployees() {
        return employees;
    }

    // Implement Iterator for iteration
    @Override
    public Iterator<Employee> iterator() {
        return employees.iterator();
    }
}
