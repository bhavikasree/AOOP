package com.example.sis;

public class Main {
    public static void main(String[] args) {
        // Create Student Service Implementation
        StudentService studentService = new StudentServiceImpl();

        // Add students
        studentService.addStudent(new Student(101, "Alice", "Computer Science"));
        studentService.addStudent(new Student(102, "Bob", "Mathematics"));
        studentService.addStudent(new Student(103, "Charlie", "Physics"));

        // Retrieve and print all students
        System.out.println("\nAll Students:");
        for (Student student : studentService.getAllStudents()) {
            System.out.println(student);
        }

        // Get a student by ID
        System.out.println("\nFetching Student with ID 102:");
        System.out.println(studentService.getStudent(102));

        // Remove a student
        studentService.removeStudent(101);

        // Print updated student list
        System.out.println("\nUpdated Student List:");
        for (Student student : studentService.getAllStudents()) {
            System.out.println(student);
        }
    }
}
