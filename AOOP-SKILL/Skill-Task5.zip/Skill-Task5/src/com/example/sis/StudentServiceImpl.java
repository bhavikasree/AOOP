package com.example.sis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentServiceImpl implements StudentService {
    private final Map<Integer, Student> studentMap;

    // Constructor
    public StudentServiceImpl() {
        this.studentMap = new HashMap<>();
    }

    // Add a student
    @Override
    public void addStudent(Student student) {
        studentMap.put(student.getId(), student);
        System.out.println("Student added: " + student);
    }

    // Remove a student by ID
    @Override
    public void removeStudent(int studentId) {
        if (studentMap.containsKey(studentId)) {
            studentMap.remove(studentId);
            System.out.println("Student with ID " + studentId + " removed.");
        } else {
            System.out.println("Student not found.");
        }
    }

    // Get a student by ID
    @Override
    public Student getStudent(int studentId) {
        return studentMap.get(studentId);
    }

    // Get all students
    @Override
    public List<Student> getAllStudents() {
        return new ArrayList<>(studentMap.values());
    }
}
