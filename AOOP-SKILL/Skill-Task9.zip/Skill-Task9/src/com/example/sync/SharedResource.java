package com.example.sync;

public class SharedResource {
    private int count = 0;

    // Synchronized method to prevent race conditions
    public synchronized void increment() {
        count++;
        System.out.println(Thread.currentThread().getName() + " increased count to: " + count);
        
        // Simulating delay
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Getter to retrieve final count
    public int getCount() {
        return count;
    }
}
