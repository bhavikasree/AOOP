package com.example.sync;

public class Main {
    public static void main(String[] args) {
        SharedResource resource = new SharedResource();

        // Creating multiple threads
        Thread t1 = new Thread(new WorkerThread(resource), "Thread-1");
        Thread t2 = new Thread(new WorkerThread(resource), "Thread-2");
        Thread t3 = new Thread(new WorkerThread(resource), "Thread-3");

        // Starting threads
        t1.start();
        t2.start();
        t3.start();

        // Ensuring all threads complete execution
        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("\nFinal count: " + resource.getCount());
    }
}
