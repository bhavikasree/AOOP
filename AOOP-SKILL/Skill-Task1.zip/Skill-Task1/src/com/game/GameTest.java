package com.game;

public class GameTest {
	 public static void main(String[] args) {
	        GameManager game1 = GameManager.getInstance();
	        game1.displaySettings(); // Default: Level 1, Easy

	        game1.setLevel(5);
	        game1.setDifficulty("Hard");

	        GameManager game2 = GameManager.getInstance();
	        game2.displaySettings(); // Output: Level 5, Hard (same instance)
	    }
	}