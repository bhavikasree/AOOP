package com.game;

public class GameManager {

	 private static GameManager instance;
	    private int level;
	    private String difficulty;

	    private GameManager() {
	        this.level = 1; // Default level
	        this.difficulty = "Easy"; // Default difficulty
	    }

	    public static GameManager getInstance() {
	        if (instance == null) {
	            instance = new GameManager();
	        }
	        return instance;
	    }

	    public void setLevel(int level) {
	        this.level = level;
	    }

	    public void setDifficulty(String difficulty) {
	        this.difficulty = difficulty;
	    }

	    public void displaySettings() {
	        System.out.println("Level: " + level + ", Difficulty: " + difficulty);
	    }
	}
