package com.ridesharing;

public class Car implements Vehicle {
    @Override
    public void bookRide() {
        System.out.println("Car ride booked!");
    }
}
