package com.ridesharing;

public class Scooter implements Vehicle {
    @Override
    public void bookRide() {
        System.out.println("Scooter ride booked!");
    }
}
