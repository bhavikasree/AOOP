package com.ridesharing;

public class Bike implements Vehicle {
    @Override
    public void bookRide() {
        System.out.println("Bike ride booked!");
    }
}
