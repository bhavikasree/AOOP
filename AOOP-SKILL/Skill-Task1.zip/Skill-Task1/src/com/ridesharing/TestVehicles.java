package com.ridesharing;

public class TestVehicles {
    public static void main(String[] args) {
        Vehicle car = new Car();
        car.bookRide(); // Output: Car ride booked!

        Vehicle bike = new Bike();
        bike.bookRide(); // Output: Bike ride booked!

        Vehicle scooter = new Scooter();
        scooter.bookRide(); // Output: Scooter ride booked!
    }
}
