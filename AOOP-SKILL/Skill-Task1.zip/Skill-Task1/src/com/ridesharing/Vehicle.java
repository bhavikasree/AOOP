package com.ridesharing;

public interface Vehicle {
    void bookRide();
}
