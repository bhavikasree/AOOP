/**
 * 
 */
/**
 * 
 */
module DesignPatternsProject {
}