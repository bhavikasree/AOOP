package com.musicstreaming;

import java.util.Random;

public class ShuffleDecorator extends MusicPlayerDecorator {
    public ShuffleDecorator(MusicPlayer player) {
        super(player);
    }

    @Override
    public void play() {
        if (new Random().nextBoolean()) {
            System.out.println("Playing a shuffled track...");
        }
        decoratedPlayer.play();
    }
}
