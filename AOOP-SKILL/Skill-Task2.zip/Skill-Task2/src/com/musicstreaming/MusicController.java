package com.musicstreaming;

public class MusicController {
    private static MusicController instance;

    private MusicController() {} // Private constructor

    public static MusicController getInstance() {
        if (instance == null) {
            instance = new MusicController();
        }
        return instance;
    }

    public void playMusic(MusicPlayer player) {
        System.out.println("== Controlling Music Player ==");
        player.play();
    }

    public void stopMusic() {
        System.out.println("Stopping music...");
    }
}
