package com.musicstreaming;

public class RadioStationPlayer implements MusicPlayer {
    @Override
    public void play() {
        System.out.println("Playing music from a radio station...");
    }
}
