package com.musicstreaming;

public class MusicStreamingFacade {
    private MusicPlayer localFilePlayer;
    private MusicPlayer onlineStreamingPlayer;
    private MusicPlayer radioStationPlayer;

    public MusicStreamingFacade() {
        this.localFilePlayer = new LocalFilePlayer();
        this.onlineStreamingPlayer = new OnlineStreamingPlayer();
        this.radioStationPlayer = new RadioStationPlayer();
    }

    public void playLocalMusic() {
        localFilePlayer.play();
    }

    public void playOnlineMusic() {
        onlineStreamingPlayer.play();
    }

    public void playRadioMusic() {
        radioStationPlayer.play();
    }
}
