package com.musicstreaming;

public class OnlineStreamingPlayer implements MusicPlayer {
    @Override
    public void play() {
        System.out.println("Playing music from an online streaming service...");
    }
}
