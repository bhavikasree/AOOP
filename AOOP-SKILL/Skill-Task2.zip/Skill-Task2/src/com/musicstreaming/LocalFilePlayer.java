package com.musicstreaming;

public class LocalFilePlayer implements MusicPlayer {
    @Override
    public void play() {
        System.out.println("Playing music from local files...");
    }
}
