package com.musicstreaming;

public enum MusicPlayerType {
    LOCAL,
    ONLINE,
    RADIO
}
