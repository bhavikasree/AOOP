package com.musicstreaming;

public abstract class MusicPlayerDecorator implements MusicPlayer {
    protected MusicPlayer decoratedPlayer;

    public MusicPlayerDecorator(MusicPlayer player) {
        this.decoratedPlayer = player;
    }

    @Override
    public void play() {
        decoratedPlayer.play();
    }
}
