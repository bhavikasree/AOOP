package com.musicstreaming;

public class VolumeControlDecorator extends MusicPlayerDecorator {
    public VolumeControlDecorator(MusicPlayer player) {
        super(player);
    }

    @Override
    public void play() {
        decoratedPlayer.play();
        System.out.println("Adjusting volume...");
    }
}
