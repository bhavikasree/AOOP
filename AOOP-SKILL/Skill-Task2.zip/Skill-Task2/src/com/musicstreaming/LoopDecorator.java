package com.musicstreaming;

public class LoopDecorator extends MusicPlayerDecorator {
    private int times;

    public LoopDecorator(MusicPlayer player, int times) {
        super(player);
        this.times = times;
    }

    @Override
    public void play() {
        for (int i = 0; i < times; i++) {
            System.out.println("Loop " + (i + 1) + ":");
            decoratedPlayer.play();
        }
    }
}
