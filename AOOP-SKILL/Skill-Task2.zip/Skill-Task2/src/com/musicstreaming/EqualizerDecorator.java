package com.musicstreaming;

public class EqualizerDecorator extends MusicPlayerDecorator {
    public EqualizerDecorator(MusicPlayer player) {
        super(player);
    }

    @Override
    public void play() {
        decoratedPlayer.play();
        System.out.println("Applying equalizer settings...");
    }
}
