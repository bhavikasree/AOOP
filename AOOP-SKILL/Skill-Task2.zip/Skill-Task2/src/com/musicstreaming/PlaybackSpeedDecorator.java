package com.musicstreaming;

public class PlaybackSpeedDecorator extends MusicPlayerDecorator {
    private double speed;

    public PlaybackSpeedDecorator(MusicPlayer player, double speed) {
        super(player);
        this.speed = speed;
    }

    @Override
    public void play() {
        decoratedPlayer.play();
        System.out.println("Playing at " + speed + "x speed.");
    }
}
