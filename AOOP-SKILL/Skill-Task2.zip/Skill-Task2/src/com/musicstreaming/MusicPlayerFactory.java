package com.musicstreaming;

public class MusicPlayerFactory {
    public static MusicPlayer createMusicPlayer(MusicPlayerType type) {
        switch (type) {
            case LOCAL:
                return new LocalFilePlayer();
            case ONLINE:
                return new OnlineStreamingPlayer();
            case RADIO:
                return new RadioStationPlayer();
            default:
                throw new IllegalArgumentException("Invalid music player type");
        }
    }
}
