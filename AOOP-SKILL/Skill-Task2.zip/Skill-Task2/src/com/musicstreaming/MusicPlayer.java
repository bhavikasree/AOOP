package com.musicstreaming;

public interface MusicPlayer {
    void play();
}
