package com.musicstreaming;

public class Main {
    public static void main(String[] args) {
        // === Factory Pattern: Create different types of music players ===
        System.out.println("\n== Using Factory Pattern ==");
        MusicPlayer localPlayer = MusicPlayerFactory.createMusicPlayer(MusicPlayerType.LOCAL);
        MusicPlayer onlinePlayer = MusicPlayerFactory.createMusicPlayer(MusicPlayerType.ONLINE);
        MusicPlayer radioPlayer = MusicPlayerFactory.createMusicPlayer(MusicPlayerType.RADIO);

        localPlayer.play();
        onlinePlayer.play();
        radioPlayer.play();

        // === Singleton Pattern: Use a single MusicController instance ===
        System.out.println("\n== Using Singleton Pattern ==");
        MusicController controller = MusicController.getInstance();
        controller.playMusic(localPlayer);
        controller.stopMusic();

        // === Decorator Pattern: Extend functionality dynamically ===
        System.out.println("\n== Using Decorator Pattern ==");
        MusicPlayer decoratedPlayer = new PlaybackSpeedDecorator(
                new LoopDecorator(new ShuffleDecorator(localPlayer), 2), 1.5
        );
        decoratedPlayer.play();
    }
}
