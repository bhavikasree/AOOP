package contacts;

import java.util.Scanner;

public class ContactApp {
    public static void main(String[] args) {
        ContactManager manager = new ContactManager();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nContact Management System");
            System.out.println("1. Add Contact");
            System.out.println("2. Search Contact");
            System.out.println("3. Remove Contact");
            System.out.println("4. Display All Contacts");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phone = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    Contact contact = new Contact(name, phone, email);
                    if (manager.addContact(contact)) {
                        System.out.println("Contact added successfully!");
                    } else {
                        System.out.println("Contact with this phone number already exists!");
                    }
                    break;
                case 2:
                    System.out.print("Enter Name to Search: ");
                    String searchName = scanner.nextLine();
                    Contact foundContact = manager.getContactByName(searchName);
                    if (foundContact != null) {
                        System.out.println("Contact Found: " + foundContact);
                    } else {
                        System.out.println("Contact not found!");
                    }
                    break;
                case 3:
                    System.out.print("Enter Name to Remove: ");
                    String removeName = scanner.nextLine();
                    if (manager.removeContact(removeName)) {
                        System.out.println("Contact removed successfully!");
                    } else {
                        System.out.println("Contact not found!");
                    }
                    break;
                case 4:
                    System.out.println("\nAll Contacts:");
                    manager.displayContacts();
                    break;
                case 5:
                    System.out.println("Exiting... Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice! Please enter a number between 1-5.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
