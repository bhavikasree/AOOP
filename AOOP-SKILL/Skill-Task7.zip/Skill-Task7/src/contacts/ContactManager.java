package contacts;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ContactManager {
    private Set<Contact> contactSet;
    private Map<String, Contact> contactMap; // Key: Name, Value: Contact object

    public ContactManager() {
        contactSet = new HashSet<>();
        contactMap = new HashMap<>();
    }

    // Add a contact
    public boolean addContact(Contact contact) {
        if (contactSet.add(contact)) {
            contactMap.put(contact.getName(), contact);
            return true;
        }
        return false; // Duplicate contact (same phone number)
    }

    // Get contact by name
    public Contact getContactByName(String name) {
        return contactMap.get(name);
    }

    // Remove contact
    public boolean removeContact(String name) {
        Contact contact = contactMap.remove(name);
        if (contact != null) {
            contactSet.remove(contact);
            return true;
        }
        return false;
    }

    // Display all contacts
    public void displayContacts() {
        for (Contact contact : contactSet) {
            System.out.println(contact);
        }
    }
}
