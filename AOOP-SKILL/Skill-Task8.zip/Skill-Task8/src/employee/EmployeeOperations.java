package employee;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

public class EmployeeOperations {
    public static void main(String[] args) {
        // List of Employees
        List<Employee> employees = Arrays.asList(
            new Employee(1, "Alice", 50000),
            new Employee(2, "Bob", 70000),
            new Employee(3, "Charlie", 60000),
            new Employee(4, "David", 90000),
            new Employee(5, "Eve", 55000),
            new Employee(6, "Frank", 72000),
            new Employee(7, "Grace", 62000),
            new Employee(8, "Hank", 80000),
            new Employee(9, "Ivy", 65000),
            new Employee(10, "Jack", 58000)
        );

        // 1️⃣ Filter employees with salary > 60000
        List<Employee> highSalaryEmployees = employees.stream()
                .filter(e -> e.getSalary() > 60000)
                .collect(Collectors.toList());

        System.out.println("\nEmployees with salary > 60000:");
        highSalaryEmployees.forEach(System.out::println);

        // 2️⃣ Sort employees by salary in descending order
        List<Employee> sortedEmployees = employees.stream()
                .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
                .collect(Collectors.toList());

        System.out.println("\nEmployees sorted by salary (Descending Order):");
        sortedEmployees.forEach(System.out::println);

        // 3️⃣ Find the highest salary
        Optional<Employee> highestSalaryEmployee = employees.stream()
                .max(Comparator.comparingDouble(Employee::getSalary));

        System.out.println("\nHighest Salary Employee: " + highestSalaryEmployee.orElse(null));

        // 4️⃣ Calculate the average salary
        OptionalDouble avgSalary = employees.stream()
                .mapToDouble(Employee::getSalary)
                .average();

        System.out.println("\nAverage Salary: " + (avgSalary.isPresent() ? avgSalary.getAsDouble() : "No data"));
    }
}

