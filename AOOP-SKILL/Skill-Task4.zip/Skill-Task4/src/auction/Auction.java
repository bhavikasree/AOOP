package auction;

// Template Method Pattern
public abstract class Auction {
    public final void startAuction() {
        announceStart();
        conductBidding();
        announceWinner();
    }

    protected abstract void announceStart();
    protected abstract void conductBidding();
    protected abstract void announceWinner();
}
