package auction;

// Observer Interface
public interface Bidder {
    void update(String item, double bidAmount);
}
