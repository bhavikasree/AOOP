package auction;

public class AuctionSystem {
    public static void main(String[] args) {
        // Create Auctioneer
        Auctioneer auctioneer = new Auctioneer("Vintage Painting");

        // Create Users (Bidders)
        User user1 = new User("Alice");
        User user2 = new User("Bob");
        User user3 = new User("Charlie");

        // Register Bidders
        auctioneer.registerBidder(user1);
        auctioneer.registerBidder(user2);
        auctioneer.registerBidder(user3);

        // Bidding Starts
        auctioneer.newBid(100.0);
        auctioneer.newBid(150.0);
        auctioneer.newBid(200.0);
        auctioneer.newBid(180.0);

        // Start Live Auction
        Auction liveAuction = new LiveAuction(auctioneer);
        liveAuction.startAuction();
    }
}
