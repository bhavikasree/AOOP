package com.example.pc;

public class Main {
    public static void main(String[] args) {
        MessageQueue queue = new MessageQueue(5); // Queue capacity of 5

        Producer producer = new Producer(queue);
        Consumer consumer = new Consumer(queue);

        Thread producerThread = new Thread(producer, "Producer-Thread");
        Thread consumerThread = new Thread(consumer, "Consumer-Thread");

        producerThread.start();
        consumerThread.start();
    }
}
