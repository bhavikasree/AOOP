package com.example.pc;

public class Producer implements Runnable {
    private MessageQueue queue;

    public Producer(MessageQueue queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        int messageCount = 1;
        try {
            while (true) {
                String message = "Message-" + messageCount;
                queue.produce(message);
                messageCount++;
                Thread.sleep(500); // Simulate production delay
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
