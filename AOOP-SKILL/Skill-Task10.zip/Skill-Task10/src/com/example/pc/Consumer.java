package com.example.pc;

public class Consumer implements Runnable {
    private MessageQueue queue;

    public Consumer(MessageQueue queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            while (true) {
                queue.consume();
                Thread.sleep(1000); // Simulate consumption delay
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
