package game;

// Abstract Creator Interface
public interface ItemFactory {

    // Method to produce Weapon items
    Item createItem(String itemType);

    // Factory Method to produce the associated item (weapon or power-up)
    Item createAssociatedItem(String associatedItemType);
}




