package game;

public class Main {
    public static void main(String[] args) {
        // Singleton GameState
        GameState gameState = GameState.getInstance();
        System.out.println("Initial Game State: " + gameState);

        // Create enemies using Factory Method
        Creature creature1 = CreatureFactory.createCreature("Undead");
        creature1.performAction();

        Creature creature2 = CreatureFactory.createCreature("Cyborg");
        creature2.performAction();

        // Create weapons and items using Abstract Factory
        GameItemFactory easyFactory = new EasyLevelFactory();
        Weapon easyWeapon = easyFactory.createWeapon();
        Item easyItem = easyFactory.createItem(); // Changed to Item as per the changes

        easyWeapon.use();
        easyItem.useEffect(); // Changed to useEffect as per the changes

        GameItemFactory hardFactory = new HardLevelFactory();
        Weapon hardWeapon = hardFactory.createWeapon();
        Item hardItem = hardFactory.createItem(); // Changed to Item as per the changes

        hardWeapon.use();
        hardItem.useEffect(); // Changed to useEffect as per the changes

        // Update game state
        gameState.setCurrentLevel(2);
        gameState.setCurrentDifficulty("HARD");
        System.out.println("Updated Game State: " + gameState);
    }
}

