package game;

// Concrete Factory for Advanced Level
public class AdvancedLevelFactory implements GameItemFactory {

    @Override
    public Weapon createWeapon() {
        return new AdvancedWeapon(); // Advanced weapon for advanced level
    }

    @Override
    public PowerUp createPowerUp() {
        return new DefensivePowerUp(); // Defensive power-up for advanced level
    }
}
