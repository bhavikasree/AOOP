package game;

// Abstract class for Combat Equipment
public abstract class CombatEquipment {
    public abstract void equip();
}

