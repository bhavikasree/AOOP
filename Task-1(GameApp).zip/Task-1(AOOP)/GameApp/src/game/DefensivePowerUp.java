package game;

public class DefensivePowerUp extends PowerUp {

    @Override
    public void triggerEffect() {
        enableShields();
    }

    // Private method to handle the shield activation
    private void enableShields() {
        System.out.println("DefensivePowerUp activated: Shields enabled!");
    }
}
