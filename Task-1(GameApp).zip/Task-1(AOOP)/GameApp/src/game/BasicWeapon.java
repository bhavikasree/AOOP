package game;

// Simple Weapon Implementation
public class BasicWeapon extends Weapon {

    @Override
    public void performAction() {
        System.out.println("Basic Weapon used: Minimal damage dealt.");
    }
}

