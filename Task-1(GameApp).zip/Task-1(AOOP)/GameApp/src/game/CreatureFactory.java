package game;

public class CreatureFactory {

    // Create a new creature based on the provided type
    public Item generateItem(String creatureType) {
        switch (creatureType.toLowerCase()) {
            case "zombie":
                return new Zombie(); // Create a Zombie instance
            case "robot":
                return new Robot();  // Create a Robot instance
            default:
                return null; // Return null if the creature type is not recognized
        }
    }
}
