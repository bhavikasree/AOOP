package game;

public class AdvancedWeapon extends Weapon {

    @Override
    public void execute() {
        dealHighDamage();
    }

    // Private method to simulate dealing high damage with the weapon
    private void dealHighDamage() {
        System.out.println("AdvancedWeapon used: High damage dealt!");
    }
}

