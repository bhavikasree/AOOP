package game;

// Factory for Basic Level Items
public class BasicLevelItemFactory implements ItemFactory {

    @Override
    public Item createItem(String itemType) {
        if (itemType.equalsIgnoreCase("Weapon")) {
            return new BasicWeapon(); // Create a simple weapon for basic level
        } else if (itemType.equalsIgnoreCase("PowerUp")) {
            return new HealthBoostPowerUp(); // Create a basic health power-up
        }
        return null;
    }

    @Override
    public Item createAssociatedItem(String associatedItemType) {
        // In this factory, the associated item functionality could be added if needed.
        return null;
    }
}

