package game;

// Simple Item Implementation for Health Boost
public class HealthBoostItem extends Item {

    @Override
    public void useEffect() {
        System.out.println("Health Boost Item used: Restores health!");
    }
}


