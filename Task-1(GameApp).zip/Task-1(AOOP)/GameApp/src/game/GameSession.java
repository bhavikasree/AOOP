package game;

public class GameSession {
    private static GameSession instance;
    private int level;
    private String difficulty;

    private GameSession() {
        // Prevent instantiation
    }

    // Provide global access to the single instance
    public static GameSession getInstance() {
        if (instance == null) {
            instance = new GameSession();
        }
        return instance;
    }

    // Set the current level
    public void updateLevel(int level) {
        this.level = level;
    }

    // Set the current difficulty
    public void updateDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    @Override
    public String toString() {
        return String.format("Current Level: %d, Difficulty: %s", level, difficulty);
    }
}


