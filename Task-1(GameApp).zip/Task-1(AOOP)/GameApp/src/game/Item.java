package game;

// Abstract class for Item
public abstract class Item {
    public abstract void useEffect();
}
