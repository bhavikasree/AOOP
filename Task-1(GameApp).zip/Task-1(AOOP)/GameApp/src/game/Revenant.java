package game;

public class Revenant extends Enemy {

    @Override
    public void performAction() {
        System.out.println("Revenant attacks with a bite!");
    }
}
