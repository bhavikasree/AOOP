package game;

// Abstract Class for Creature
public abstract class Creature {
    
    // Abstract method for creature action
    public abstract void performAction();
}







