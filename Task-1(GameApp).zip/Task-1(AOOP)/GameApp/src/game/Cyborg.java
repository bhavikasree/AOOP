package game;

public class Cyborg extends Creature {
    @Override
    public void executeAction() {
        System.out.println("Cyborg attacks with laser beams!");
    }
}
