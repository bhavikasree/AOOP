package com.bankapp;

public class BankAccountMain {
    public static void main(String[] args) {
        BankAccount sharedAccount = new BankAccount(1000); // Initial balance of $1000

        // Creating multiple user transactions
        Thread user1 = new Thread(new BankTransaction(sharedAccount, true, 500), "User1");
        Thread user2 = new Thread(new BankTransaction(sharedAccount, false, 200), "User2");
        Thread user3 = new Thread(new BankTransaction(sharedAccount, true, 300), "User3");
        Thread user4 = new Thread(new BankTransaction(sharedAccount, false, 700), "User4");

        // Start the threads
        user1.start();
        user2.start();
        user3.start();
        user4.start();
        
        // Wait for all threads to complete execution
        try {
            user1.join();
            user2.join();
            user3.join();
            user4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Display final balance
        System.out.println("Final Account Balance: $" + sharedAccount.getBalance());
    }
}
