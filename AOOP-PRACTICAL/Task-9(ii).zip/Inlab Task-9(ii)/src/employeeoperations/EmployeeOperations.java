package employeeoperations;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeOperations {
    public static void main(String[] args) {
        // Step 1: Create a list of employees
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Alice", 30, "HR", 50000));
        employees.add(new Employee("Bob", 35, "IT", 70000));
        employees.add(new Employee("Charlie", 28, "Finance", 60000));
        employees.add(new Employee("David", 40, "IT", 80000));
        employees.add(new Employee("Eve", 32, "HR", 55000));

        // Step 2: Filter employees by Department (e.g., IT Department)
        System.out.println("\nEmployees in IT Department:");
        List<Employee> itEmployees = employees.stream()
                .filter(e -> e.getDepartment().equalsIgnoreCase("IT"))
                .collect(Collectors.toList());
        itEmployees.forEach(System.out::println);

        // Step 3: Sort employees by name
        System.out.println("\nEmployees sorted by name:");
        List<Employee> sortedByName = employees.stream()
                .sorted(Comparator.comparing(Employee::getName))
                .collect(Collectors.toList());
        sortedByName.forEach(System.out::println);

        // Step 4: Find the employee with the highest salary
        System.out.println("\nEmployee with the highest salary:");
        Employee highestPaidEmployee = employees.stream()
                .max(Comparator.comparing(Employee::getSalary))
                .orElse(null);
        System.out.println(highestPaidEmployee);

        // Step 5: Calculate the average salary of employees
        System.out.println("\nAverage Salary of Employees:");
        double averageSalary = employees.stream()
                .mapToDouble(Employee::getSalary)
                .average()
                .orElse(0.0);
        System.out.println("Average Salary: " + averageSalary);
    }
}
