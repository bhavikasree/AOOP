package com.messaging;

import java.util.LinkedList;
import java.util.Queue;

public class MessageQueue {
    private Queue<String> queue = new LinkedList<>();
    private final int capacity;

    // Constructor to define the queue capacity
    public MessageQueue(int capacity) {
        this.capacity = capacity;
    }

    // Synchronized method for Producer to add messages
    public synchronized void produce(String message) throws InterruptedException {
        while (queue.size() == capacity) {
            wait(); // Wait if buffer is full
        }
        queue.add(message);
        System.out.println("Produced: " + message);
        notify(); // Notify Consumer that a message is available
    }

    // Synchronized method for Consumer to retrieve messages
    public synchronized String consume() throws InterruptedException {
        while (queue.isEmpty()) {
            wait(); // Wait if buffer is empty
        }
        String message = queue.poll();
        System.out.println("Consumed: " + message);
        notify(); // Notify Producer that space is available
        return message;
    }
}
