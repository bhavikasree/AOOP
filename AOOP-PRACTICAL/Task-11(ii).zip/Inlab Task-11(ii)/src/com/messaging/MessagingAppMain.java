package com.messaging;

public class MessagingAppMain {
    public static void main(String[] args) {
        MessageQueue messageQueue = new MessageQueue(3); // Shared buffer with capacity 3

        // Creating Producer and Consumer threads
        Thread producerThread = new Thread(new Producer(messageQueue), "Producer");
        Thread consumerThread = new Thread(new Consumer(messageQueue), "Consumer");

        // Start both threads
        producerThread.start();
        consumerThread.start();

        // Wait for threads to complete
        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Messaging Application Completed.");
    }
}
