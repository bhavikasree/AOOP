package com.messaging;

public class Consumer implements Runnable {
    private MessageQueue messageQueue;

    public Consumer(MessageQueue messageQueue) {
        this.messageQueue = messageQueue;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 5; i++) { // Consuming 5 messages
                messageQueue.consume();
                Thread.sleep(1500); // Simulating processing delay
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
