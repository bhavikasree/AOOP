package com.messaging;

public class Producer implements Runnable {
    private MessageQueue messageQueue;

    public Producer(MessageQueue messageQueue) {
        this.messageQueue = messageQueue;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 5; i++) { // Producing 5 messages
                String message = "Message " + i;
                messageQueue.produce(message);
                Thread.sleep(1000); // Simulating delay
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
