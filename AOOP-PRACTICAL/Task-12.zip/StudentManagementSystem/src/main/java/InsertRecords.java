import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class InsertRecords {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/StudentDB", "root", "yourpassword");

            String sql = "INSERT INTO Registration VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, 100);
            ps.setString(2, "Alice");
            ps.setString(3, "New York");
            ps.setString(4, "Computer Science");
            ps.executeUpdate();

            ps.setInt(1, 101);
            ps.setString(2, "Bob");
            ps.setString(3, "California");
            ps.setString(4, "Electrical Engineering");
            ps.executeUpdate();

            ps.setInt(1, 102);
            ps.setString(2, "Charlie");
            ps.setString(3, "Texas");
            ps.setString(4, "Mechanical Engineering");
            ps.executeUpdate();

            ps.setInt(1, 103);
            ps.setString(2, "David");
            ps.setString(3, "Florida");
            ps.setString(4, "Civil Engineering");
            ps.executeUpdate();

            System.out.println("Records Inserted Successfully!");
            
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
