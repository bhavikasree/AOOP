import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DeleteRecords {
    public static void main(String[] args) {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish database connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/StudentDB", "root", "yourpassword");

            // Delete record where ID = 101
            PreparedStatement ps = con.prepareStatement("DELETE FROM Registration WHERE id=?");
            ps.setInt(1, 101);
            ps.executeUpdate();

            System.out.println("✅ Record deleted successfully.");

            // Close connection
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
