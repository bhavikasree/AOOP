import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DisplayRecords {
    public static void main(String[] args) {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish database connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/StudentDB", "root", "yourpassword");

            // Create a statement
            Statement stmt = con.createStatement();

            // Execute SQL query to retrieve all student records
            ResultSet rs = stmt.executeQuery("SELECT * FROM Registration");

            // Display records
            System.out.println("ID  |  Name  |  Address  |  Program");
            System.out.println("-------------------------------------");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + "  |  " +
                                   rs.getString(2) + "  |  " +
                                   rs.getString(3) + "  |  " +
                                   rs.getString(4));
            }

            // Close connections
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
