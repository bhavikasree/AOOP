import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UpdateRecords {
    public static void main(String[] args) {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish database connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/StudentDB", "root", "yourpassword");

            // Update program for student ID 100
            PreparedStatement ps = con.prepareStatement("UPDATE Registration SET program=? WHERE id=?");
            ps.setString(1, "Data Science");
            ps.setInt(2, 100);
            ps.executeUpdate();

            // Update program for student ID 101
            ps.setString(1, "AI & ML");
            ps.setInt(2, 101);
            ps.executeUpdate();

            System.out.println("✅ Records updated successfully.");

            // Close connection
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
