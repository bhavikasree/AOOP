package bank;

public class Main {
    public static void main(String[] args) {
        // Create an Account object with initial balance
        Account account = new Account(1001, 5000.00);

        // Creating multiple threads using TransactionRunnable
        Thread t1 = new Thread(new TransactionRunnable(account, 1000, true), "Thread-1");
        Thread t2 = new Thread(new TransactionRunnable(account, 2000, false), "Thread-2");
        Thread t3 = new Thread(new TransactionRunnable(account, 500, true), "Thread-3");

        // Creating multiple threads using TransactionThread
        TransactionThread t4 = new TransactionThread(account, 1500, false);
        TransactionThread t5 = new TransactionThread(account, 700, true);
        TransactionThread t6 = new TransactionThread(account, 3000, false);

        // Set thread names for better debugging
        t4.setName("Thread-4");
        t5.setName("Thread-5");
        t6.setName("Thread-6");

        // Start all threads
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();

        // Ensure all threads complete execution before displaying final balance
        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
            t5.join();
            t6.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Display the final balance
        System.out.println("Final Account Balance: " + account.getBalance());
    }
}
