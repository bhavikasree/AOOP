package bank;

public class TransactionRunnable implements Runnable {
    private Account account;
    private double amount;
    private boolean isDeposit; // true for deposit, false for withdrawal

    // Constructor
    public TransactionRunnable(Account account, double amount, boolean isDeposit) {
        this.account = account;
        this.amount = amount;
        this.isDeposit = isDeposit;
    }

    // Implementing run() method
    @Override
    public void run() {
        if (isDeposit) {
            account.deposit(amount);
        } else {
            account.withdraw(amount);
        }
    }
}
