package bank;

public class Account {
    private int accountNumber;
    private double balance;

    // Constructor
    public Account(int accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Getter for account number
    public int getAccountNumber() {
        return accountNumber;
    }

    // Synchronized method for deposit
    public synchronized void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println(Thread.currentThread().getName() + " deposited " + amount + ". New Balance: " + balance);
        }
    }

    // Synchronized method for withdrawal
    public synchronized void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println(Thread.currentThread().getName() + " withdrew " + amount + ". New Balance: " + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " attempted to withdraw " + amount + " but insufficient funds. Balance: " + balance);
        }
    }

    // Method to get current balance
    public double getBalance() {
        return balance;
    }
}
