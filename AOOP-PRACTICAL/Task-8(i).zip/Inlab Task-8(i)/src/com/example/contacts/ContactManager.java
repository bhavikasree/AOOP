package com.example.contacts;

import java.util.HashMap;
import java.util.Map;

public class ContactManager {
    private Map<String, String> contacts; // Store contacts in a HashMap

    public ContactManager() {
        this.contacts = new HashMap<>();
    }

    // Method to add a contact
    public void addContact(String name, String phoneNumber) {
        contacts.put(name, phoneNumber);
        System.out.println("Contact added: " + name + " - " + phoneNumber);
    }

    // Method to retrieve a contact by name
    public String getContact(String name) {
        return contacts.getOrDefault(name, "Contact not found");
    }

    // Method to display all contacts
    public void displayContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts found.");
        } else {
            System.out.println("Contact List:");
            for (Map.Entry<String, String> entry : contacts.entrySet()) {
                System.out.println(entry.getKey() + " - " + entry.getValue());
            }
        }
    }
}
