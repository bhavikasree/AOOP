package com.example.contacts;

public class Main {
    public static void main(String[] args) {
        ContactManager manager = new ContactManager();

        // Adding contacts
        manager.addContact("Alice", "123-456-7890");
        manager.addContact("Bob", "987-654-3210");
        manager.addContact("Charlie", "555-666-7777");

        // Retrieving a contact
        System.out.println("\nRetrieving Bob's Contact:");
        System.out.println("Bob - " + manager.getContact("Bob"));

        // Displaying all contacts
        System.out.println("\nAll Contacts:");
        manager.displayContacts();
    }
}
