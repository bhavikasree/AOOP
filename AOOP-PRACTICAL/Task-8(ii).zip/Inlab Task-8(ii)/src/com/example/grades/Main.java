package com.example.grades;

import java.util.Set;

public class Main {
    public static void main(String[] args) {
        StudentGradeManager gradeManager = new StudentGradeManager();

        // Adding student grades
        gradeManager.addGrade(101, 85);
        gradeManager.addGrade(101, 90);
        gradeManager.addGrade(102, 78);
        gradeManager.addGrade(102, 92);
        gradeManager.addGrade(103, 88);

        // Retrieving and displaying grades for a specific student
        System.out.println("\nGrades for Student ID 101:");
        Set<Integer> grades101 = gradeManager.getGrades(101);
        System.out.println(grades101);

        // Displaying all student grades
        System.out.println("\nAll Student Grades:");
        gradeManager.displayAllGrades();
    }
}
