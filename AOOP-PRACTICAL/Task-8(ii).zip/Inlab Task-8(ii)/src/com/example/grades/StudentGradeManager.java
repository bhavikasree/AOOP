package com.example.grades;

import java.util.*;

public class StudentGradeManager {
    private Map<Integer, Set<Integer>> studentGrades; // Map to store student ID and grades

    public StudentGradeManager() {
        this.studentGrades = new HashMap<>();
    }

    // Method to add a grade for a student
    public void addGrade(int studentId, int grade) {
        studentGrades.putIfAbsent(studentId, new HashSet<>()); // Create a new set if not present
        studentGrades.get(studentId).add(grade); // Add grade to the set
        System.out.println("Grade " + grade + " added for Student ID: " + studentId);
    }

    // Method to retrieve grades for a student
    public Set<Integer> getGrades(int studentId) {
        return studentGrades.getOrDefault(studentId, new HashSet<>());
    }

    // Method to display all student grades
    public void displayAllGrades() {
        if (studentGrades.isEmpty()) {
            System.out.println("No student grades available.");
        } else {
            System.out.println("Student Grades:");
            for (Map.Entry<Integer, Set<Integer>> entry : studentGrades.entrySet()) {
                System.out.println("Student ID: " + entry.getKey() + " -> Grades: " + entry.getValue());
            }
        }
    }
}
