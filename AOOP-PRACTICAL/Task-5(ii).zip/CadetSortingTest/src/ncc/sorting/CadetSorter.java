package ncc.sorting;

import java.util.List;
import java.util.Collections;

public class CadetSorter {
    public static void sortCadets(List<String> cadets) {
        Collections.sort(cadets); // Sorts the list alphabetically
    }
}
