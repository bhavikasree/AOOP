package ncc.sorting;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<String> cadets = Arrays.asList("Zara", "Arjun", "Mohan", "Amit");

        System.out.println("Before Sorting: " + cadets);
        CadetSorter.sortCadets(cadets);
        System.out.println("After Sorting: " + cadets);
    }
}
