package coffeeshop;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class CoffeeShopPayroll {
    public static void main(String[] args) {
        // Step 1: Create a list to store employees
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Employee1", 30, 5));
        employees.add(new Employee("Employee2", 28, 4));
        employees.add(new Employee("Employee3", 25, 3));
        employees.add(new Employee("Employee4", 22, 1));
        employees.add(new Employee("Employee5", 20, 0));

        // Step 2: Sort Employees based on experience in descending order
        employees.sort((e1, e2) -> Integer.compare(e2.experience, e1.experience));

        // Step 3: Print sorted employees
        System.out.println("Employees sorted by experience:");
        employees.forEach(System.out::println);

        // Step 4: Define Predicate for filtering employees eligible for bonus (more than 2 years experience)
        Predicate<Employee> bonusEligible = e -> e.experience > 2;

        // Step 5: Filter employees eligible for bonus
        List<Employee> bonusRecipients = employees.stream()
                .filter(bonusEligible)
                .collect(Collectors.toList());

        // Step 6: Print employees eligible for a bonus
        System.out.println("\nEmployees eligible for a bonus:");
        bonusRecipients.forEach(System.out::println);
    }
}

