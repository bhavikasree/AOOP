package coffeeshop;

public class Employee {
    String name;
    int age;
    int experience;

    // Constructor to initialize employee details
    public Employee(String name, int age, int experience) {
        this.name = name;
        this.age = age;
        this.experience = experience;
    }

    // Override toString method for easy printing
    @Override
    public String toString() {
        return "Employee{name='" + name + "', age=" + age + ", experience=" + experience + " years}";
    }
}
